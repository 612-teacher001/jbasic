public class IntegerArray {
    public static void main(String[] args) {
        int[] numbers = {1, 7, 2, 7, 3};
        for (int number : numbers) {
            System.out.println(number);
        }
    }
}